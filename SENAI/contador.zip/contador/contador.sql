-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tempo de Generação: Nov 23, 2007 at 04:08 PM
-- Versão do Servidor: 4.1.9
-- Versão do PHP: 4.3.10
-- 
-- Banco de Dados: `visitas`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `contador`
-- 

CREATE TABLE `contador` (
  `visitas` int(5) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Extraindo dados da tabela `contador`
-- 

INSERT INTO `contador` VALUES (3501);
INSERT INTO `contador` VALUES (17);
